#!/bin/bash
sudo su
make clean
make
sudo rmmod chardevLeds.
sudo insmod chardevLeds.ko
sudo mknod /dev/chardevLeds -m 666 c 250 0
sudo echo 123 > /dev/chardevLeds
sudo cat /dev/chardevLeds
